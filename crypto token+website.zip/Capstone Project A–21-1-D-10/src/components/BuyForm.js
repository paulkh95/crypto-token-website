import React, { Component } from 'react'


let ws = new WebSocket('wss://stream.binance.com:9443/ws/ethusdt@trade');
let ws1 = new WebSocket('wss://stream.binance.com:9443/ws/btcusdt@trade');

let ethprice,btcprice,price;
ws.onmessage = (event)=>{

  let stock = JSON.parse(event.data);
  ethprice=stock.p;
  

}

ws1.onmessage = (event)=>{

  let stock = JSON.parse(event.data);
  btcprice=stock.p;
  

}


class BuyForm extends Component {
  constructor(props) {
    super(props)
    this.state = {
      output: '0',
      ppcprice: '0',
      originalprice: '0'
    }
    
    this.getPrice = this.getPrice.bind(this);
  }

 

  render() {
    this.state.ppcprice = price;
    return (
      <form className="mb-3" onSubmit={(event) => {
          event.preventDefault()
          let etherAmount
          etherAmount = this.input.value.toString()
          etherAmount = window.web3.utils.toWei(etherAmount, 'Ether')
          // console.log(etherAmount)
          // console.log(this.state.ppcprice) //rate
          let rate = window.web3.utils.toWei(this.state.ppcprice.toString(), 'Ether')
          let p = this.input.value / parseFloat(this.state.ppcprice)
          let tkamount = window.web3.utils.toWei(p.toString(), 'Ether')
          this.props.buyTokens(tkamount,etherAmount,rate)
        }}>
        <div>
          <label className="float-left"><b>Input</b></label>
          <span className="float-right text-muted">
            Balance: {window.web3.utils.fromWei(this.props.ethBalance, 'Ether')}
          </span>
        </div>
        <div className="input-group mb-4">
          <input
            type="text"
            onChange={(event) => {
              this.state.originalprice = this.input.value.toString()
              const etherAmount = this.input.value.toString()
              this.setState({
                output: etherAmount / this.state.ppcprice
              })
            }}
            ref={(input) => { this.input = input }}
            className="form-control form-control-lg"
            placeholder="0"
            required />
          <div className="input-group-append">
            <div className="input-group-text">
            
              &nbsp;&nbsp;&nbsp; ETH
            </div>
          </div>
        </div>
        <div>
          <label className="float-left"><b>Output</b></label>
          <span className="float-right text-muted">
            Balance: {window.web3.utils.fromWei(this.props.tokenBalance, 'Ether')}
          </span>
        </div>
        <div className="input-group mb-2">
          <input
            type="text"
            className="form-control form-control-lg"
            placeholder="0"
            value={this.state.output}
            disabled
          />
          <div className="input-group-append">
            <div className="input-group-text">
           
              &nbsp; PPC
            </div>
          </div>
        </div>
        <div className="mb-5">
          <span className="float-left text-muted">Exchange Rate</span>
          <span className="float-right text-muted">{this.state.ppcprice} ETH = 1 PPC</span>
        </div>
        <button type="submit" className="btn btn-primary btn-block btn-lg">SWAP!</button>
      </form>
    );
  }


  componentDidMount() {
    // Call this function so that it fetch first time right after mounting the component
    this.getPrice();
    // set Interval
    this.interval = setInterval(this.getPrice, 2000);
    
  }

  async getPrice() {
    
  
    try{
      
        
        
    let etherumPrice= parseFloat(ethprice);
    let bitcoinPrice= parseFloat(btcprice);
    price= (0.1*bitcoinPrice + 1.5*etherumPrice)/etherumPrice;
    
    // console.log(price);
    if(btcprice !== undefined && ethprice !== undefined )
      {
        
        // this.state.ppcprice=price;
        this.setState({ ppcprice: price });
        this.setState({ output: this.state.originalprice / price });
        
        
 
      }
      else{
        return 0;
       
      }
      
      
      
      

     } catch(e) { console.error(e); }


  }

  componentWillUnmount() {

    // Clear the interval right before component unmount
    console.log("component sell had been unmounted");
    clearInterval(this.interval);
  }



}

export default BuyForm;
